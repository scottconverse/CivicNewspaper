# Share Package

Generated: 2026-06-28T12:01:46.302415100+00:00

Website home: https://eternal-trellis-g2f7.here.now
RSS feed: https://eternal-trellis-g2f7.here.now/feed.xml

## Suggested Community Posts

### Draft: Longmont Museum Closure for Expansion: The Longmont Museum is closed during construction until Fall 2026, but education programs and events will continue.

Local update: Draft: Longmont Museum Closure for Expansion: The Longmont Museum is closed during construction until Fall 2026, but education programs and events will continue.. Read it in the latest issue: https://eternal-trellis-g2f7.here.now/watch/5.html

### Draft: Technical Issues with Building Services Online Permitting Portal: Longmont City’s online permitting portal is experiencing technical issues, impacting local businesses and construction activities.

Local update: Draft: Technical Issues with Building Services Online Permitting Portal: Longmont City’s online permitting portal is experiencing technical issues, impacting local businesses and construction activities.. Read it in the latest issue: https://eternal-trellis-g2f7.here.now/watch/4.html

### Draft: Longmont Museum Events and Programs: The Longmont Museum offers diverse educational programs, workshops, and tours for all age groups, contributing to the community's cultural and historical awareness.

Local update: Draft: Longmont Museum Events and Programs: The Longmont Museum offers diverse educational programs, workshops, and tours for all age groups, contributing to the community's cultural and historical awareness.. Read it in the latest issue: https://eternal-trellis-g2f7.here.now/watch/3.html

### Draft: Book-a-Librarian Workshop for Tweens: The library is hosting a creative arts workshop aimed at helping tweens develop meaningful friendships, scheduled for June 29th.

Local update: Draft: Book-a-Librarian Workshop for Tweens: The library is hosting a creative arts workshop aimed at helping tweens develop meaningful friendships, scheduled for June 29th.. Read it in the latest issue: https://eternal-trellis-g2f7.here.now/watch/2.html

### Draft: Vision Zero Projects in Longmont: The City of Longmont is working on Vision Zero initiatives aimed at improving transportation safety, involving public participation which could lead to significant policy changes.

Local update: Draft: Vision Zero Projects in Longmont: The City of Longmont is working on Vision Zero initiatives aimed at improving transportation safety, involving public participation which could lead to significant policy changes.. Read it in the latest issue: https://eternal-trellis-g2f7.here.now/watch/1.html

## Hosting Notes

Publish instantly with here.now. Use GitHub Pages if you want a durable public archive in your own repository. Cloudflare Pages and Netlify remain good technical-hosting options.
