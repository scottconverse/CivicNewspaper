# The Longmont Ledger

Local news and community information.

Generated: 2026-06-28T12:01:46.302415100+00:00

## This Issue

- [Draft: Longmont Museum Closure for Expansion: The Longmont Museum is closed during construction until Fall 2026, but education programs and events will continue.](https://eternal-trellis-g2f7.here.now/watch/5.html) - watch - 2026-06-28T11:57:17.469681300+00:00
- [Draft: Technical Issues with Building Services Online Permitting Portal: Longmont City’s online permitting portal is experiencing technical issues, impacting local businesses and construction activities.](https://eternal-trellis-g2f7.here.now/watch/4.html) - watch - 2026-06-28T11:55:20.713689900+00:00
- [Draft: Longmont Museum Events and Programs: The Longmont Museum offers diverse educational programs, workshops, and tours for all age groups, contributing to the community's cultural and historical awareness.](https://eternal-trellis-g2f7.here.now/watch/3.html) - watch - 2026-06-28T11:53:16.367560900+00:00
- [Draft: Book-a-Librarian Workshop for Tweens: The library is hosting a creative arts workshop aimed at helping tweens develop meaningful friendships, scheduled for June 29th.](https://eternal-trellis-g2f7.here.now/watch/2.html) - watch - 2026-06-28T11:51:27.698727700+00:00
- [Draft: Vision Zero Projects in Longmont: The City of Longmont is working on Vision Zero initiatives aimed at improving transportation safety, involving public participation which could lead to significant policy changes.](https://eternal-trellis-g2f7.here.now/watch/1.html) - watch - 2026-06-28T11:49:50.585614800+00:00

## Links

- Website home: https://eternal-trellis-g2f7.here.now
- RSS feed: https://eternal-trellis-g2f7.here.now/feed.xml
