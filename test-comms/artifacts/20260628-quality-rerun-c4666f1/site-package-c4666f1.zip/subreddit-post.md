# The Longmont Ledger

5 local update(s).

Top item: Draft: Longmont Museum Closure for Expansion: The Longmont Museum is closed during construction until Fall 2026, but education programs and events will continue.

Read the issue: https://eternal-trellis-g2f7.here.now

Sources and corrections policy are included on the site.
