# The Longmont Ledger

5 local update(s).

Top item: Draft: Vision Zero Projects in Longmont: The city is working on Vision Zero initiatives aimed at improving transportation safety, which affects every resident’s daily commute.

Read the issue: https://emerald-island-gevx.here.now

Sources and corrections policy are included on the site.
