# CivicNewspaper Source Import Test Fixtures

Generated local fixtures for Colorado municipal/county source import parsing. These files are intentionally realistic and messy, with no private personal information.

URL counts are approximate because parsers may normalize trailing punctuation, split wrapped PDF text differently, or treat social/community links as non-importable.

## colorado-source-list-clean.csv
- Format: CSV
- Intended parser behavior: Baseline clean import with canonical columns and mostly official/local URLs.
- Approximate expected importable URL count: 40
- Known duplicates / invalid URLs: None intentional; None intentional
- Bug it is meant to catch: Baseline clean import with canonical columns and mostly official/local URLs.

## colorado-source-list-messy.xlsx
- Format: XLSX
- Intended parser behavior: URLs embedded in notes, blank rows, duplicates, invalid rows, and multi-column source discovery.
- Approximate expected importable URL count: 28
- Known duplicates / invalid URLs: Brighton AgendaCenter and Aurora Legistar repeat; media rows contain multiple URLs.; example.com, http://, www dot larimer dot gov, call-city-clerk text.
- Bug it is meant to catch: URLs embedded in notes, blank rows, duplicates, invalid rows, and multi-column source discovery.

## colorado-source-list-human-notes.txt
- Format: TXT
- Intended parser behavior: Plain-text extraction with bullets, angle brackets, trailing punctuation, prose, duplicates, and malformed near-URLs.
- Approximate expected importable URL count: 36
- Known duplicates / invalid URLs: Brighton AgendaCenter repeated with punctuation.; htp://bad-brighton-url, https://, www dot bouldercolorado dot gov, mailto example.
- Bug it is meant to catch: Plain-text extraction with bullets, angle brackets, trailing punctuation, prose, duplicates, and malformed near-URLs.

## colorado-source-list-briefing.docx
- Format: DOCX
- Intended parser behavior: Word document parsing through headings, prose, tables, bullets, embedded/trailing-punctuation URLs.
- Approximate expected importable URL count: 42
- Known duplicates / invalid URLs: Brighton AgendaCenter and Denver Legistar duplicate/trailing punctuation.; htp://bad-denver-url, https://, www dot auroragov dot org.
- Bug it is meant to catch: Word document parsing through headings, prose, tables, bullets, embedded/trailing-punctuation URLs.

## colorado-source-list-exported.pdf
- Format: PDF text
- Intended parser behavior: Extractable PDF text with headings, table cells, wrapped URLs, and footnotes.
- Approximate expected importable URL count: 43
- Known duplicates / invalid URLs: Public notice/statewide source may duplicate municipal notices; no exact official duplicates beyond notes.; example.com, http://, www dot denvergov dot org.
- Bug it is meant to catch: Extractable PDF text with headings, table cells, wrapped URLs, and footnotes.

## colorado-source-list-scanned-style.pdf
- Format: PDF image/scanned-style
- Intended parser behavior: OCR-required PDF path; URL text is visible but not extractable by ordinary text extraction.
- Approximate expected importable URL count: 30
- Known duplicates / invalid URLs: None exact among visible scan list.; Community/social links included for classification, but visible text is image-only.
- Bug it is meant to catch: OCR-required PDF path; URL text is visible but not extractable by ordinary text extraction.

## colorado-source-list-edge-cases.xlsx
- Format: XLSX
- Intended parser behavior: Split URLs, trailing punctuation, case normalization, query strings, multi-URL cells, hidden/far-right columns.
- Approximate expected importable URL count: 22
- Known duplicates / invalid URLs: Brighton http/https variants; Larimer BOCC repeated rows.; www dot jeffco dot us, http://, social/community classification cases.
- Bug it is meant to catch: Split URLs, trailing punctuation, case normalization, query strings, multi-URL cells, hidden/far-right columns.

## Generation limitations
- URLs are real-looking and mostly official/local, but they were not exhaustively live-verified.
- `colorado-source-list-scanned-style.pdf` is image-backed and should require OCR; ordinary PDF text extraction is expected to find few or no URLs.
- Some agenda/RSS labels are intentionally publisher shorthand rather than guaranteed canonical feed endpoints.
